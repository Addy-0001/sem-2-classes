package Week5.Assignments;

public class MultiplyThreeNumbers {
    public static int multiply(int num1, int num2, int num3) {
        return num1 * num2 * num3;
    }

    public static void main(String[] args) {
        int result = multiply(2, 3, 4);
        System.out.println("Result: " + result);
    }
}
